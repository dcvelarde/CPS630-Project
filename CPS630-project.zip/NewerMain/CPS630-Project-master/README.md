# CPS630-Project

AngularJS scripts are under the Project/scripts folder

Project/back-end/app.js file contains the nodejs API server setup that includes some sample API calls
